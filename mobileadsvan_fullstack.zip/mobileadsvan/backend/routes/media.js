// ================================
// routes/media.js — Media Upload Routes
// POST   /api/media/upload     (admin — upload files)
// GET    /api/media            (public — list media)
// PUT    /api/media/:id        (admin — update caption/category)
// DELETE /api/media/:id        (admin — delete file)
// ================================

const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const db = require('../database');
const { verifyToken } = require('../middleware/auth');
const { upload, getFileType } = require('../middleware/upload');

// --------------------------------
// POST /api/media/upload
// Admin — upload image(s) or video(s)
// Field name: 'files' (multiple)
// --------------------------------
router.post('/upload', verifyToken, upload.array('files', 20), (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, message: 'No files uploaded.' });
    }

    const { caption = '', category = 'campaign' } = req.body;
    const uploaded = [];

    req.files.forEach(file => {
      const fileType = getFileType(file.mimetype);
      const subFolder = fileType === 'image' ? 'images' : 'videos';

      const mediaItem = {
        id: uuidv4(),
        filename: file.filename,
        original_name: file.originalname,
        type: fileType,
        mimetype: file.mimetype,
        size_kb: Math.round(file.size / 1024),
        url: `/uploads/${subFolder}/${file.filename}`,
        caption: caption,
        category: category, // campaign | portfolio | team | other
        is_featured: false,
        uploaded_by: req.admin.id,
        created_at: new Date().toISOString()
      };

      db.get('media').push(mediaItem).write();
      uploaded.push(mediaItem);
    });

    return res.status(201).json({
      success: true,
      message: `${uploaded.length} file(s) uploaded successfully.`,
      data: uploaded
    });

  } catch (err) {
    console.error('Upload error:', err);
    return res.status(500).json({ success: false, message: err.message || 'Upload failed.' });
  }
});

// --------------------------------
// GET /api/media
// Public — list all media
// Query: ?type=image|video&category=campaign&featured=true
// --------------------------------
router.get('/', (req, res) => {
  try {
    const { type, category, featured, page = 1, limit = 50 } = req.query;

    let media = db.get('media').value();

    if (type) media = media.filter(m => m.type === type);
    if (category) media = media.filter(m => m.category === category);
    if (featured === 'true') media = media.filter(m => m.is_featured);

    // Newest first
    media = media.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    // Pagination
    const total = media.length;
    const start = (parseInt(page) - 1) * parseInt(limit);
    const paginated = media.slice(start, start + parseInt(limit));

    return res.json({
      success: true,
      data: paginated,
      counts: {
        total,
        images: db.get('media').filter({ type: 'image' }).value().length,
        videos: db.get('media').filter({ type: 'video' }).value().length
      },
      pagination: { total, page: parseInt(page), limit: parseInt(limit) }
    });

  } catch (err) {
    console.error('Get media error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// --------------------------------
// PUT /api/media/:id
// Admin — update caption, category, featured
// --------------------------------
router.put('/:id', verifyToken, (req, res) => {
  try {
    const item = db.get('media').find({ id: req.params.id }).value();
    if (!item) return res.status(404).json({ success: false, message: 'Media not found.' });

    const { caption, category, is_featured } = req.body;
    const updates = {};
    if (caption !== undefined) updates.caption = caption;
    if (category !== undefined) updates.category = category;
    if (is_featured !== undefined) updates.is_featured = Boolean(is_featured);

    db.get('media').find({ id: req.params.id }).assign(updates).write();

    return res.json({ success: true, message: 'Media updated.', data: { ...item, ...updates } });

  } catch (err) {
    console.error('Update media error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// --------------------------------
// DELETE /api/media/:id
// Admin — delete file from disk + DB
// --------------------------------
router.delete('/:id', verifyToken, (req, res) => {
  try {
    const item = db.get('media').find({ id: req.params.id }).value();
    if (!item) return res.status(404).json({ success: false, message: 'Media not found.' });

    // Delete file from disk
    const filePath = path.join(__dirname, '..', item.url);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    // Remove from DB
    db.get('media').remove({ id: req.params.id }).write();

    return res.json({ success: true, message: 'File deleted.' });

  } catch (err) {
    console.error('Delete media error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
