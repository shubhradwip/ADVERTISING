// ================================
// routes/settings.js — Site Settings & Packages
// GET /api/settings            (public)
// PUT /api/settings            (admin)
// GET /api/packages            (public)
// PUT /api/packages/:id        (admin)
// GET /api/dashboard/stats     (admin)
// ================================

const express = require('express');
const router = express.Router();
const db = require('../database');
const { verifyToken } = require('../middleware/auth');

// --------------------------------
// GET /api/settings  (public)
// --------------------------------
router.get('/settings', (req, res) => {
  const settings = db.get('settings').value();
  return res.json({ success: true, data: settings });
});

// --------------------------------
// PUT /api/settings  (admin)
// --------------------------------
router.put('/settings', verifyToken, (req, res) => {
  try {
    const allowed = [
      'business_name', 'tagline', 'phone', 'whatsapp',
      'email', 'location', 'price_per_van_day',
      'facebook_url', 'instagram_url', 'youtube_url',
      'areas_covered', 'hero_stats'
    ];

    const updates = {};
    allowed.forEach(key => {
      if (req.body[key] !== undefined) updates[key] = req.body[key];
    });
    updates.updated_at = new Date().toISOString();

    db.set('settings', { ...db.get('settings').value(), ...updates }).write();

    return res.json({ success: true, message: 'Settings updated.', data: db.get('settings').value() });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// --------------------------------
// GET /api/packages  (public)
// --------------------------------
router.get('/packages', (req, res) => {
  const packages = db.get('packages').filter({ is_active: true }).value();
  return res.json({ success: true, data: packages });
});

// --------------------------------
// PUT /api/packages/:id  (admin)
// --------------------------------
router.put('/packages/:id', verifyToken, (req, res) => {
  try {
    const pkg = db.get('packages').find({ id: req.params.id }).value();
    if (!pkg) return res.status(404).json({ success: false, message: 'Package not found.' });

    const allowed = ['name', 'vans', 'price_per_van_day', 'features', 'not_included', 'is_featured', 'is_active'];
    const updates = {};
    allowed.forEach(key => { if (req.body[key] !== undefined) updates[key] = req.body[key]; });

    db.get('packages').find({ id: req.params.id }).assign(updates).write();
    return res.json({ success: true, message: 'Package updated.', data: { ...pkg, ...updates } });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// --------------------------------
// GET /api/dashboard/stats  (admin)
// Summary stats for dashboard
// --------------------------------
router.get('/dashboard/stats', verifyToken, (req, res) => {
  try {
    const enquiries = db.get('enquiries').value();
    const media = db.get('media').value();

    const today = new Date().toDateString();
    const todayEnquiries = enquiries.filter(e =>
      new Date(e.created_at).toDateString() === today
    ).length;

    const thisMonth = new Date();
    const monthEnquiries = enquiries.filter(e => {
      const d = new Date(e.created_at);
      return d.getMonth() === thisMonth.getMonth() &&
             d.getFullYear() === thisMonth.getFullYear();
    }).length;

    return res.json({
      success: true,
      data: {
        enquiries: {
          total: enquiries.length,
          new: enquiries.filter(e => e.status === 'new').length,
          today: todayEnquiries,
          this_month: monthEnquiries,
          contacted: enquiries.filter(e => e.status === 'contacted').length,
          closed: enquiries.filter(e => e.status === 'closed').length
        },
        media: {
          total: media.length,
          images: media.filter(m => m.type === 'image').length,
          videos: media.filter(m => m.type === 'video').length
        },
        settings: db.get('settings').pick(['business_name', 'price_per_van_day']).value()
      }
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
