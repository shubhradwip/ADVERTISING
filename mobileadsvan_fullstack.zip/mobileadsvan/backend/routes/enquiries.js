// ================================
// routes/enquiries.js — Enquiry/Lead Routes
// POST /api/enquiries          (public — form submission)
// GET  /api/enquiries          (admin only)
// GET  /api/enquiries/:id      (admin only)
// PUT  /api/enquiries/:id      (admin only — update status/notes)
// DELETE /api/enquiries/:id    (admin only)
// ================================

const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const db = require('../database');
const { verifyToken } = require('../middleware/auth');

// --------------------------------
// POST /api/enquiries
// Public — submit contact form
// --------------------------------
router.post('/', (req, res) => {
  try {
    const { name, phone, business_type, budget, message } = req.body;

    // Phone is required
    if (!phone || phone.trim().length < 7) {
      return res.status(400).json({
        success: false,
        message: 'A valid phone number is required.'
      });
    }

    const enquiry = {
      id: uuidv4(),
      name: name?.trim() || 'Not provided',
      phone: phone.trim(),
      business_type: business_type?.trim() || 'Not specified',
      budget: budget?.trim() || 'Not specified',
      message: message?.trim() || '',
      status: 'new',           // new | read | contacted | closed
      notes: '',               // admin notes
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    db.get('enquiries').push(enquiry).write();

    return res.status(201).json({
      success: true,
      message: 'Enquiry submitted! We will contact you shortly.',
      id: enquiry.id
    });

  } catch (err) {
    console.error('Enquiry submit error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// --------------------------------
// GET /api/enquiries
// Admin — get all enquiries (with filters)
// Query: ?status=new&page=1&limit=20
// --------------------------------
router.get('/', verifyToken, (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;

    let enquiries = db.get('enquiries').value();

    // Filter by status if provided
    if (status && status !== 'all') {
      enquiries = enquiries.filter(e => e.status === status);
    }

    // Sort newest first
    enquiries = enquiries.sort((a, b) =>
      new Date(b.created_at) - new Date(a.created_at)
    );

    // Pagination
    const total = enquiries.length;
    const start = (parseInt(page) - 1) * parseInt(limit);
    const paginated = enquiries.slice(start, start + parseInt(limit));

    // Count by status
    const all = db.get('enquiries').value();
    const counts = {
      all: all.length,
      new: all.filter(e => e.status === 'new').length,
      read: all.filter(e => e.status === 'read').length,
      contacted: all.filter(e => e.status === 'contacted').length,
      closed: all.filter(e => e.status === 'closed').length
    };

    return res.json({
      success: true,
      data: paginated,
      counts,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / limit) }
    });

  } catch (err) {
    console.error('Get enquiries error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// --------------------------------
// GET /api/enquiries/:id
// Admin — get single enquiry
// --------------------------------
router.get('/:id', verifyToken, (req, res) => {
  const enquiry = db.get('enquiries').find({ id: req.params.id }).value();
  if (!enquiry) return res.status(404).json({ success: false, message: 'Enquiry not found.' });

  // Auto-mark as read
  if (enquiry.status === 'new') {
    db.get('enquiries').find({ id: req.params.id })
      .assign({ status: 'read', updated_at: new Date().toISOString() }).write();
    enquiry.status = 'read';
  }

  return res.json({ success: true, data: enquiry });
});

// --------------------------------
// PUT /api/enquiries/:id
// Admin — update status or notes
// Body: { status, notes }
// --------------------------------
router.put('/:id', verifyToken, (req, res) => {
  try {
    const enquiry = db.get('enquiries').find({ id: req.params.id }).value();
    if (!enquiry) return res.status(404).json({ success: false, message: 'Enquiry not found.' });

    const { status, notes } = req.body;
    const validStatuses = ['new', 'read', 'contacted', 'closed'];

    const updates = { updated_at: new Date().toISOString() };
    if (status && validStatuses.includes(status)) updates.status = status;
    if (notes !== undefined) updates.notes = notes;

    db.get('enquiries').find({ id: req.params.id }).assign(updates).write();

    return res.json({ success: true, message: 'Enquiry updated.', data: { ...enquiry, ...updates } });

  } catch (err) {
    console.error('Update enquiry error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// --------------------------------
// DELETE /api/enquiries/:id
// Admin — delete an enquiry
// --------------------------------
router.delete('/:id', verifyToken, (req, res) => {
  const enquiry = db.get('enquiries').find({ id: req.params.id }).value();
  if (!enquiry) return res.status(404).json({ success: false, message: 'Enquiry not found.' });

  db.get('enquiries').remove({ id: req.params.id }).write();
  return res.json({ success: true, message: 'Enquiry deleted.' });
});

module.exports = router;
