// ================================
// database.js — JSON Database (lowdb)
// Schema & initialization
// ================================

const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

// DB file location
const dbPath = path.join(__dirname, 'db.json');
const adapter = new FileSync(dbPath);
const db = low(adapter);

// ================================
// DATABASE SCHEMA (defaults)
// ================================
db.defaults({

  // Admin users table
  admins: [
    {
      id: uuidv4(),
      username: process.env.ADMIN_USERNAME || 'mobileadsvan',
      // Password hashed on first init
      password: bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'admin@2025', 10),
      email: process.env.ADMIN_EMAIL || 'soumomazumdar292@gmail.com',
      role: 'superadmin',
      created_at: new Date().toISOString(),
      last_login: null
    }
  ],

  // Enquiries / leads from contact form
  enquiries: [
    /*
    {
      id: 'uuid',
      name: 'string',
      phone: 'string',         // required
      business_type: 'string',
      budget: 'string',
      message: 'string',
      status: 'new|read|contacted|closed',
      created_at: 'ISO date',
      updated_at: 'ISO date',
      notes: 'string'          // admin notes
    }
    */
  ],

  // Media library (images & videos)
  media: [
    /*
    {
      id: 'uuid',
      filename: 'stored-filename.jpg',
      original_name: 'original.jpg',
      type: 'image|video',
      mimetype: 'image/jpeg',
      size_kb: 1024,
      url: '/uploads/images/filename.jpg',
      caption: 'string',
      category: 'campaign|portfolio|team|other',
      is_featured: false,
      uploaded_by: 'admin-id',
      created_at: 'ISO date'
    }
    */
  ],

  // Campaign packages
  packages: [
    {
      id: uuidv4(),
      name: 'Basic',
      vans: 1,
      price_per_van_day: 2000,
      duration_hours: 8,
      features: ['LED Light Display', 'Sound System', 'GPS Tracking', '8 Hours Per Day', '1 Van'],
      not_included: ['Audio Editing', 'Banner Design', 'Banner Print', 'Leaflet Distribution'],
      is_featured: false,
      is_active: true,
      created_at: new Date().toISOString()
    },
    {
      id: uuidv4(),
      name: 'Standard',
      vans: 2,
      price_per_van_day: 2000,
      duration_hours: 8,
      features: ['LED Light Display', 'Sound System', 'GPS Tracking', '8 Hours Per Day', '2 Vans', 'Free Banner Design', 'Free Leaflet Distribution'],
      not_included: ['Audio Editing', 'Banner Print'],
      is_featured: true,
      is_active: true,
      created_at: new Date().toISOString()
    },
    {
      id: uuidv4(),
      name: 'Premium',
      vans: 4,
      price_per_van_day: 2000,
      duration_hours: 8,
      features: ['LED Light Display', 'Sound System', 'GPS Tracking', '8 Hours Per Day', '4 Vans', 'Free Banner Design', 'Free Audio Editing', 'Free Leaflet Distribution', 'Free Banner Print'],
      not_included: [],
      is_featured: false,
      is_active: true,
      created_at: new Date().toISOString()
    }
  ],

  // Site settings (editable from admin)
  settings: {
    business_name: 'Mobile Ads Van',
    tagline: "Put Your Brand On Every Street In Kolkata",
    phone: '9836788726',
    whatsapp: '919836788726',
    email: 'soumomazumdar292@gmail.com',
    location: 'Kolkata, West Bengal, India',
    price_per_van_day: 2000,
    facebook_url: '#',
    instagram_url: '#',
    youtube_url: '#',
    areas_covered: ['New Town', 'Eco Park', 'Keshtopur', 'Jagatpur', 'Hatiyara', 'Shyambazar', 'Nager Bazar', 'Rajarhat', 'Gauranga Nagar'],
    hero_stats: {
      clients: 7,
      areas: 8,
      founded: 2025
    },
    updated_at: new Date().toISOString()
  }

}).write();

module.exports = db;
