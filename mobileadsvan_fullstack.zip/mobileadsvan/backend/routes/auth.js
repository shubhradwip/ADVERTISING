// ================================
// routes/auth.js — Authentication Routes
// POST /api/auth/login
// POST /api/auth/logout
// GET  /api/auth/verify
// PUT  /api/auth/change-password
// ================================

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database');
const { verifyToken } = require('../middleware/auth');
require('dotenv').config();

// --------------------------------
// POST /api/auth/login
// Body: { username, password }
// --------------------------------
router.post('/login', (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required.'
      });
    }

    // Find admin by username
    const admin = db.get('admins').find({ username }).value();
    if (!admin) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.'
      });
    }

    // Compare password
    const isMatch = bcrypt.compareSync(password, admin.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.'
      });
    }

    // Update last login
    db.get('admins')
      .find({ id: admin.id })
      .assign({ last_login: new Date().toISOString() })
      .write();

    // Generate JWT (expires in 8 hours)
    const token = jwt.sign(
      { id: admin.id, username: admin.username, role: admin.role },
      process.env.JWT_SECRET,
      { expiresIn: '8h' }
    );

    return res.json({
      success: true,
      message: 'Login successful.',
      token,
      admin: {
        id: admin.id,
        username: admin.username,
        email: admin.email,
        role: admin.role
      }
    });

  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// --------------------------------
// GET /api/auth/verify
// Verify token is still valid
// --------------------------------
router.get('/verify', verifyToken, (req, res) => {
  const admin = db.get('admins').find({ id: req.admin.id }).value();
  if (!admin) {
    return res.status(404).json({ success: false, message: 'Admin not found.' });
  }
  return res.json({
    success: true,
    admin: {
      id: admin.id,
      username: admin.username,
      email: admin.email,
      role: admin.role,
      last_login: admin.last_login
    }
  });
});

// --------------------------------
// PUT /api/auth/change-password
// Body: { current_password, new_password }
// --------------------------------
router.put('/change-password', verifyToken, (req, res) => {
  try {
    const { current_password, new_password } = req.body;

    if (!current_password || !new_password) {
      return res.status(400).json({ success: false, message: 'Both fields required.' });
    }

    if (new_password.length < 6) {
      return res.status(400).json({ success: false, message: 'New password must be at least 6 characters.' });
    }

    const admin = db.get('admins').find({ id: req.admin.id }).value();
    const isMatch = bcrypt.compareSync(current_password, admin.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
    }

    const hashed = bcrypt.hashSync(new_password, 10);
    db.get('admins').find({ id: req.admin.id }).assign({ password: hashed }).write();

    return res.json({ success: true, message: 'Password changed successfully.' });

  } catch (err) {
    console.error('Change password error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
