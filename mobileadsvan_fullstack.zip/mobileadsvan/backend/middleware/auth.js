// ================================
// middleware/auth.js — JWT Auth Middleware
// ================================

const jwt = require('jsonwebtoken');
require('dotenv').config();

// Verify JWT token on protected routes
const verifyToken = (req, res, next) => {
  // Get token from Authorization header: "Bearer <token>"
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Access denied. No token provided.'
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.admin = decoded; // attach decoded payload to request
    next();
  } catch (err) {
    return res.status(403).json({
      success: false,
      message: 'Invalid or expired token. Please login again.'
    });
  }
};

// Optional: require superadmin role
const requireSuperAdmin = (req, res, next) => {
  if (req.admin && req.admin.role === 'superadmin') {
    next();
  } else {
    return res.status(403).json({
      success: false,
      message: 'Superadmin access required.'
    });
  }
};

module.exports = { verifyToken, requireSuperAdmin };
