// ================================
// middleware/upload.js — Multer File Upload
// ================================

const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const MAX_SIZE = (parseInt(process.env.MAX_FILE_SIZE_MB) || 20) * 1024 * 1024;

// Allowed MIME types
const ALLOWED_TYPES = {
  'image/jpeg': 'images',
  'image/jpg': 'images',
  'image/png': 'images',
  'image/webp': 'images',
  'video/mp4': 'videos',
  'video/quicktime': 'videos',
  'video/avi': 'videos',
  'video/x-msvideo': 'videos',
  'video/x-matroska': 'videos'
};

// Dynamic storage: images → uploads/images/, videos → uploads/videos/
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const folder = ALLOWED_TYPES[file.mimetype] || 'images';
    const dest = path.join(__dirname, '..', 'uploads', folder);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    // Generate unique filename: uuid + original extension
    const ext = path.extname(file.originalname).toLowerCase();
    const uniqueName = uuidv4() + ext;
    cb(null, uniqueName);
  }
});

// File filter — only allow defined types
const fileFilter = (req, file, cb) => {
  if (ALLOWED_TYPES[file.mimetype]) {
    cb(null, true);
  } else {
    cb(new Error(`File type not allowed: ${file.mimetype}`), false);
  }
};

// Export multer instance
const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_SIZE }
});

// Helper: get file type from mimetype
const getFileType = (mimetype) => {
  return mimetype.startsWith('image/') ? 'image' : 'video';
};

module.exports = { upload, getFileType };
